const express = require("express");
const router = express.Router();
const db = require("../config");

router.get("/signout", (req, res) => {
	req.session.user = null;
	res.redirect("/");
});

router.get("/edit", async (req, res) => {
	if (!req.session.user) res.redirect("/login");
	else {
		try {
			const feedbacks = await db.feedbacks(req.session.user.id);
			const data = feedbacks.map(feedback => {
				const { name, form1, form2, id } = feedback;
				const rating = ((form1 - 1) * 5 + form2) / 5;
				return { name, rating, id };
			});
			res.render("edit", { data });
		} catch (e) {
			console.log(e);
			res.status(400).json("Internal error.");
		}
	}
});

router.get("/edit/:teacherID", async (req, res) => {
	if (!req.session.user) res.redirect("/login");
	else {
		try {
			const details = await db.getFeedback(
				req.params.teacherID,
				req.session.user.id
			);
			const { teacherID } = req.params;
			res.render("feedback2", { details, teacherID });
		} catch (e) {
			console.log(e);
			res.status(400).json("Internal error.");
		}
	}
});

router.post("/edit/feedback", async (req, res) => {
	if (!req.session.user) res.redirect("login");
	else {
		try {
			const { form1, form2, teacherID } = req.body;
			if (!form1 || !form2) return res.status(400).json("error");
			const response = await db.updateFeedback(
				form1,
				form2,
				teacherID,
				req.session.user.id
			);
			console.log(`Feedback updated, affected rows: ${response.affectedRows}`);
			res.render("congrats", {
				error: "Your feedback for today has been updated.",
			});
		} catch (e) {
			console.log(e);
			res.status(400).json("error");
		}
	}
});

router.get("/", async (req, res) => {
	if (req.session.user) {
		try {
			if (req.session.user.role === "Student") {
				const teachers = await db.teachers();
				res.render("student", teachers);
			}
			if (req.session.user.role === "Teacher") {
				const overallAverage = await db.getFeedbacksAverage(
					req.session.user.id
				);
				const todayAverage = await db.getTodayAverage(req.session.user.id);
				const weeklyAverage = await db.weeklyAverage(req.session.user.id);
				const monthlyAverage = await db.monthlyAverage(req.session.user.id);
				res.render("teacher", {
					teacherID: req.session.user.id,
					todayAverage,
					todayMessage: showMessage(todayAverage),
					overallAverage,
					overallMessage: showMessage(overallAverage),
					teacherName: req.session.user.name,
					weeklyAverage,
					weeklyMessage: showMessage(weeklyAverage),
					monthlyAverage,
					monthlyMessage: showMessage(monthlyAverage),
				});
			}
		} catch (e) {
			console.log(e);
			res.status(400).json("Internal error.");
		}
	} else res.redirect("/login");
});

router.get("/login", (req, res) => {
	if (req.session.user) res.redirect("/");
	else res.render("login");
});

router.post("/login", async (req, res) => {
	const { email, password } = req.body;
	try {
		const user = await db.login(email);
		if (user.password == password) {
			req.session.user = user;
			res.redirect("/");
			return;
		} else return res.render("login", { error: "Wrong Credentials." });
	} catch (e) {
		if (!e) {
			return res.render("login", { error: "Wrong Credentials." });
		}
		console.log(e);
		res.status(400).json("Internal error.");
	}
});

const showMessage = avg => {
	switch (parseInt(avg)) {
		case 0:
			return "Remarks: Very poor performance. Needs improvement.";
		case 1:
			return "Remarks: More effort needed.";
		case 2:
			return "Remarks: Average performance. More efforts would be appreciated.";
		case 3:
			return "Remarks: Good performance. Keep up the good work!";
		case 4:
			return "Remarks: Excellent performance. You're close to a 5-star rating!";
		case 5:
			return "Remarks: Outstanding! You're a 5-star teacher!";
	}
};

module.exports = router;
