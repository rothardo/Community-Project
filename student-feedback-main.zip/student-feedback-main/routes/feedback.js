const express = require("express");
const router = express.Router();
const db = require("../config");

router.get("/:teacherID", (req, res) => {
	if (!req.session.user) res.redirect("/login");
	else res.render("feedbackForm", { teacherID: req.params.teacherID });
});

router.get("/get/average/:date/:teacher", async (req, res) => {
	if (!req.session.user) res.redirect("/login");
	else {
		try {
			const { teacher, date } = req.params;
			const average = await db.getAverage(teacher, date);
			res.json(average);
		} catch (e) {
			console.log(e);
			res.status(400).json("Internal error.");
		}
	}
});

router.post("/", async (req, res) => {
	if (!req.session.user) res.redirect("login");
	else {
		try {
			const add = await db.checkToday(req.session.user.id, req.body.teacherID);
			if (add.length !== 0)
				return res.render("congrats", {
					error:
						"You have already submitted a feedback for this teacher today. Come back tomorrow!",
				});
			const resp = await db.addFeedback({
				...req.body,
				studentID: req.session.user.id,
			});
			res.render("congrats");
		} catch (e) {
			console.log(e);
			res.status(400).json("error");
		}
	}
});

module.exports = router;
