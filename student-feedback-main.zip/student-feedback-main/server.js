require("dotenv").config();
const express = require("express");
const cookieSession = require("cookie-session");
const path = require("path");
const cookieParser = require("cookie-parser");
const logger = require("morgan");
const mysql = require("mysql");
const indexRouter = require("./routes");
const feedbackRoutes = require("./routes/feedback");
const app = express();

const connection = mysql.createConnection({
	password: process.env.DB_PASSWORD,
	user: process.env.DB_USER,
	database: process.env.DB_NAME,
	host: process.env.DB_HOST,
});

// view engine setup
app.set("views", path.join(__dirname, "views"));
app.set("view engine", "ejs");

app.use(logger("dev"));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, "public")));
app.use(
	cookieSession({
		name: "session",
		keys: ["MySQL", "Project"],
	})
);

app.use("/", indexRouter);
app.use("/feedback", feedbackRoutes);

connection.connect(err => {
	if (err) {
		console.log(`Couldn't establish database connection.`);
		console.log(err);
		return;
	}
	app.listen(process.env.PORT, () =>
		console.log(`Listening on port ${process.env.PORT}.`)
	);
	console.log("Database connected.");
	connection.end();
});
