const mysql = require("mysql");
const moment = require("moment");

const pool = mysql.createPool({
	connectionLimit: 10,
	password: process.env.DB_PASSWORD,
	user: process.env.DB_USER,
	database: process.env.DB_NAME,
	host: process.env.DB_HOST,
	port: process.env.DB_PORT,
});

const data = {};

data.updateFeedback = (form1, form2, teacherID, studentID) =>
	new Promise((resolve, reject) => {
		pool.query(
			`UPDATE feedbacks SET form1 = ?, form2 = ? WHERE teacher = ? AND student = ? AND date = ?`,
			[
				form1,
				form2,
				teacherID,
				studentID,
				moment(Date.now()).format("DD-MM-YYYY"),
			],
			(er, res) => {
				if (er) return reject(er);
				return resolve(res);
			}
		);
	});

data.feedbacks = studentID =>
	new Promise((resolve, reject) => {
		pool.query(
			`SELECT teachers.name, teachers.id, feedbacks.form1, feedbacks.form2 FROM feedbacks JOIN teachers ON feedbacks.teacher = teachers.id WHERE feedbacks.student = ? AND feedbacks.date = ?`,
			[studentID, moment(Date.now()).format("DD-MM-YYYY")],
			(er, res) => {
				if (er) return reject(er);
				return resolve(res);
			}
		);
	});

data.getFeedback = (teacherID, studentID) =>
	new Promise((resolve, reject) => {
		pool.query(
			`SELECT * FROM feedbacks WHERE teacher = ? AND student = ? AND date = ?`,
			[teacherID, studentID, moment(Date.now()).format("DD-MM-YYYY")],
			(er, res) => {
				if (er) return reject(er);
				return resolve(res[0]);
			}
		);
	});

data.checkToday = (studentID, teacherID) =>
	new Promise((resolve, reject) => {
		pool.query(
			`SELECT id FROM feedbacks where student = ? AND teacher = ? AND date = ?`,
			[studentID, teacherID, moment(Date.now()).format("DD-MM-YYYY")],
			(er, res) => {
				if (er) return reject(er);
				resolve(res);
			}
		);
	});

data.getAverage = (teacherID, date) =>
	new Promise((resolve, reject) => {
		pool.query(
			`SELECT form1, form2 FROM feedbacks where teacher = ? AND date = ?`,
			[teacherID, moment(date).format("DD-MM-YYYY")],
			(er, res) => {
				if (er) return reject(er);
				const response = res.map(entry => {
					const { form1, form2 } = entry;
					return ((form1 - 1) * 5 + form2) / 5;
				});
				var average = 0;
				for (var i = 0; i < response.length; i++)
					average += response[i] / response.length;
				return resolve(average);
			}
		);
	});

data.weeklyAverage = teacherID =>
	new Promise((resolve, reject) => {
		pool.query(
			`SELECT * FROM feedbacks WHERE teacher = ? AND dateSeconds > ?`,
			[teacherID, Date.now() - 604800000],
			(er, res) => {
				if (er) return reject(er);
				const response = res.map(entry => {
					const { form1, form2 } = entry;
					return ((form1 - 1) * 5 + form2) / 5;
				});
				var average = 0;
				for (var i = 0; i < response.length; i++)
					average += response[i] / response.length;
				return resolve(average);
			}
		);
	});

data.monthlyAverage = teacherID =>
	new Promise((resolve, reject) => {
		pool.query(
			`SELECT * FROM feedbacks WHERE teacher = ? AND dateSeconds > ?`,
			[teacherID, Date.now() - 2592000000],
			(er, res) => {
				if (er) return reject(er);
				const response = res.map(entry => {
					const { form1, form2 } = entry;
					return ((form1 - 1) * 5 + form2) / 5;
				});
				var average = 0;
				for (var i = 0; i < response.length; i++)
					average += response[i] / response.length;
				return resolve(average);
			}
		);
	});

data.getTodayAverage = teacherID =>
	new Promise((resolve, reject) => {
		pool.query(
			`SELECT form1, form2 FROM feedbacks WHERE teacher = ? AND date = ?`,
			[teacherID, moment(Date.now()).format("DD-MM-YYYY")],
			(er, res) => {
				if (er) return reject(er);
				const response = res.map(entry => {
					const { form1, form2 } = entry;
					return ((form1 - 1) * 5 + form2) / 5;
				});
				var average = 0;
				for (var i = 0; i < response.length; i++)
					average += response[i] / response.length;
				resolve(average);
			}
		);
	});

data.getFeedbacksAverage = teacherID =>
	new Promise((resolve, reject) => {
		pool.query(
			`SELECT form1, form2 FROM feedbacks WHERE teacher = ?`,
			[teacherID],
			(er, data) => {
				if (er) return reject(er);
				const response = data.map(entry => {
					const { form1, form2 } = entry;
					return ((form1 - 1) * 5 + form2) / 5;
				});
				var average = 0;
				for (var i = 0; i < response.length; i++)
					average += response[i] / response.length;
				resolve(average);
			}
		);
	});

data.teachers = () =>
	new Promise((resolve, reject) => {
		pool.query(`SELECT * FROM teachers`, (er, teachers) => {
			if (er) return reject(er);
			return resolve({ teachers });
		});
	});

data.login = email =>
	new Promise((resolve, reject) => {
		pool.query(`SELECT * FROM students WHERE email = ?`, [email], (er, res) => {
			if (er) return reject(er);
			if (res.length === 0) {
				pool.query(
					`SELECT * FROM teachers WHERE email = ?`,
					[email],
					(err, result) => {
						if (err) return reject(err);
						if (result.length === 0) return reject(false);
						return resolve({ ...result[0], role: "Teacher" });
					}
				);
				return;
			}
			return resolve({ ...res[0], role: "Student" });
		});
	});

data.addFeedback = feedback => {
	const { form1, form2, teacherID, studentID } = feedback;
	return new Promise((resolve, reject) => {
		pool.query(
			`INSERT INTO feedbacks (teacher, student, form1, form2, date, dateSeconds) VALUES (?, ?, ?, ?, ?, ?)`,
			[
				parseInt(teacherID),
				parseInt(studentID),
				parseInt(form1),
				parseInt(form2),
				moment(Date.now()).format("DD-MM-YYYY"),
				Date.now(),
			],
			(er, res) => {
				if (er) return reject(er);
				console.log(`Insert successfully, ID = ${res.insertId}.`);
				return resolve(true);
			}
		);
	});
};

module.exports = data;
